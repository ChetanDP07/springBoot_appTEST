package com.chetanpatil.fullStack_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullStackBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
